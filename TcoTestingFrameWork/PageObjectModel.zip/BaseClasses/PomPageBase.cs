﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TcoTestingFrameWork.ComponenetHelper;
using TcoTestingFrameWork.Settings;

namespace TcoTestingFrameWork.BaseClasses
{
    public  class PomPageBase
    {
        private IWebDriver _driver;

        [FindsBy(How = How.Id, Using = "LinkHomePage")]
        private IWebElement HomePageLink;

        [FindsBy(How = How.Id, Using = "ctl00_CleckControll1_btnLogOut")]
        private IWebElement LogOutLink;
        public PomPageBase(IWebDriver driver)
        {
            PageFactory.InitElements(driver, this);
        }

       
            public void NavigateToTcoWelcomPage()
            { 
               if (GenericHelper.IsElementPresents(By.Id("LinkHomePage")))            
               HomePageLink.Click();
            }
        }
    }
    

