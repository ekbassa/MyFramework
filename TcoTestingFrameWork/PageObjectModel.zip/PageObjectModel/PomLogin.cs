﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TcoTestingFrameWork.BaseClasses;
using TcoTestingFrameWork.Settings;

namespace TcoTestingFrameWork.PageObjectModel
{
    public  class PomLogin : PomPageBase
    {
        private IWebDriver _driver;
        #region IwebElement
        [FindsBy(How=How.Id,Using = "txtUserName")]
        private IWebElement  UserNameTextBox;

        [FindsBy(How = How.Id, Using = "txtPassword")]
        private IWebElement  PassWORDTextBox;

        [FindsBy(How = How.Id, Using = "btnLogIn")]
        private IWebElement LoginButton;
        #endregion

        //constructor
        public PomLogin(IWebDriver driver ):base(driver)
        {
            _driver = driver;
        }
        #region Actions
        public PomWelcomToTCO  Login(string userName,string Password)
        {
            UserNameTextBox.SendKeys(userName);
            PassWORDTextBox.SendKeys(Password);
            LoginButton.Click();
            return new PomWelcomToTCO(_driver);
        }
        #endregion


        #region Navigation

        #endregion
    }
}
