﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TcoTestingFrameWork.BaseClasses;
using TcoTestingFrameWork.Settings;

namespace TcoTestingFrameWork.PageObjectModel
{
    public  class PomWelcomToTCO :PomPageBase
    {
        private IWebDriver _driver;
        #region IwebElement
        [FindsBy(How = How.XPath, Using = "//table[@id='tblMainMenuNL']/descendant::td[position()=1]")]
        private IWebElement ClerkMenu;

        [FindsBy(How = How.XPath, Using = "//table[@id='tblMainMenuNL']/descendant::td[position()=2]")]
        private IWebElement DataEntry;

        [FindsBy(How = How.XPath, Using = "//table[@id='tblMainMenuNL']/descendant::td[position()=3]")]
        private IWebElement ReservationCenter;

        [FindsBy(How = How.XPath, Using = "//table[@id='tblMainMenuNL']/descendant::td[position()=5]")]
        private IWebElement FinanceAndControl;

        #endregion
        public PomWelcomToTCO(IWebDriver driver):base(driver)
        {
            _driver = driver;
        }

        #region Actions
        public PomDocketList ClickClerkMenu()
        {
            ClerkMenu.Click();
            return new PomDocketList(_driver);
        }
        public void ClickDataEntry()
        {
            DataEntry.Click();
        }
        public void ClickReservationCenter()
        {
            ReservationCenter.Click();
        }
        public void ClickFinancaAnCotrol()
        {
            FinanceAndControl.Click();
        }
        #endregion

        #region Navigation
        public void NavigateToClerkMenu()
        {

        }
        #endregion
    }
}
