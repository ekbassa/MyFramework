﻿namespace TcoTestingFrameWork.Configuration
{
    public enum BrowserType
    {
        FireFox,
        Chrome,
        IExplorer
    }
}
