﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TcoTestingFrameWork.Settings;

namespace TcoTestingFrameWork.ComponentHelper
{
    public  class MouseActionsHelper
    {
        
        public static void RightClick(IWebElement  element)
        {
            ///  this Method is going to perform a right click on a specific web element
            ///  
            //create the actions class instance
            Actions act = new Actions(ObjectRepository.Driver);
            act.ContextClick(element)
               .Build()
               .Perform();   
        }

       public static void DoubleClick(IWebElement element)
        {
            ///  this Method is going to perform Double  click on a specific web element

            Actions act = new Actions(ObjectRepository.Driver);
            act.DoubleClick(element)
               .Build()
               .Perform();
        }
    }
}
