﻿using OpenQA.Selenium;
using TcoTestingFrameWork.Settings;

namespace TcoTestingFrameWork.ComponenetHelper
{
    public static class NavigationHelper
    {
        public static void NavigateToUrl(string Url)
        {
            ObjectRepository.Driver.Navigate().GoToUrl(Url);
        }

        public static void NavigateToHomePage()
        {
            ObjectRepository.Driver.FindElement(By.XPath("//div[@class='HomeImage']")).Click();
        }

        public static void TcoLogOut()
        {
            ObjectRepository.Driver.FindElement(By.Id("ctl00_CleckControll1_btnLogOut")).Click();
        }
    }
}
